package org.example.jdbc3.vo연습;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Bag {
    private String name;
    private int age;
    private String hobby;
    private String tel;
}
